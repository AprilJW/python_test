A = '123'
# print(dir())
def f1():
    pass