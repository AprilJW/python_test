from distutils.core import setup
setup(name='m',
      version='1.0',
      description='Python test m',
      author='JW',
      author_email='',
      url='',
      packages=['m', 'm.m1', 'm.m1.m2'],
     )
# packages里面填写，所有包名